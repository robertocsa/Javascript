
// Pendulum variables
let origin;
let armLength;
let angle;
let angularVelocity;
let angularAcceleration;
let bobRadius = 20;

// Physics parameters controlled by user
let gravity;
let damping;

// UI Elements
let lengthSlider, initialAngleSlider, gravitySlider, dampingSlider;
let lengthLabel, angleLabel, gravityLabel, dampingLabel;
let resetButton;

// UI positioning constants
const UI_X_LABELS = 20;
const UI_X_SLIDERS = 300;
const UI_SLIDER_WIDTH = 150;
let ui_y_current = 20;
const UI_Y_SPACING = 35;
const UI_TEXT_OFFSET_Y = -17; // To align p text baseline with slider center

function setup() {
  createCanvas(windowWidth, windowHeight);
  colorMode(HSB, 360, 100, 100); // Hue, Saturation, Brightness

  document.body.style.background = '#222'; // Dark background for the page

  origin = createVector(width / 2, height / 4);

  // --- Create UI Elements ---
  lengthLabel = createP('Comprimento do pêndulo / Arm Length:');
  lengthLabel.position(UI_X_LABELS, ui_y_current + UI_TEXT_OFFSET_Y);
  lengthSlider = createSlider(50, 600, 200, 1); // min, max, default, step
  lengthSlider.position(UI_X_SLIDERS, ui_y_current);
  lengthSlider.style('width', UI_SLIDER_WIDTH + 'px');
  ui_y_current += UI_Y_SPACING;

  angleLabel = createP('Ângulo inicial (graus) /Initial Angle (deg):');
  angleLabel.position(UI_X_LABELS, ui_y_current + UI_TEXT_OFFSET_Y);
  initialAngleSlider = createSlider(-90, 90, 45, 1); // degrees
  initialAngleSlider.position(UI_X_SLIDERS, ui_y_current);
  initialAngleSlider.style('width', UI_SLIDER_WIDTH + 'px');
  ui_y_current += UI_Y_SPACING;

  gravityLabel = createP('Escala da força da gravidade / Gravity scale:');
  gravityLabel.position(UI_X_LABELS, ui_y_current + UI_TEXT_OFFSET_Y);
  gravitySlider = createSlider(0.01, 1.0, 0.4, 0.01);
  gravitySlider.position(UI_X_SLIDERS, ui_y_current);
  gravitySlider.style('width', UI_SLIDER_WIDTH + 'px');
  ui_y_current += UI_Y_SPACING;

  dampingLabel = createP('Amortecimento / Damping:');
  dampingLabel.position(UI_X_LABELS, ui_y_current + UI_TEXT_OFFSET_Y);
  dampingSlider = createSlider(0, 0.05, 0.001, 0.0001);
  dampingSlider.position(UI_X_SLIDERS, ui_y_current);
  dampingSlider.style('width', UI_SLIDER_WIDTH + 'px');
  ui_y_current += UI_Y_SPACING;

  resetButton = createButton('Reset Pendulum');
  resetButton.position(UI_X_LABELS, ui_y_current);
  resetButton.mousePressed(resetPendulum);

  // Style UI elements
  selectAll('p').forEach(p => {
    p.style('color', 'white');
    p.style('font-family', 'Arial, sans-serif');
    p.style('font-size', '14px');
  });
  resetButton.style('padding', '8px 12px')
             .style('background-color', '#777')
             .style('color', 'white')
             .style('border', 'none')
             .style('border-radius', '4px')
             .style('cursor', 'pointer')
             .style('font-family', 'Arial, sans-serif');

  // Initialize pendulum state
  resetPendulum();
}

function resetPendulum() {
  // Use slider value for arm length, but cap it to fit on screen
  let desiredArmLength = lengthSlider.value();
  let maxDisplayableLength = (height - origin.y) - bobRadius - 10; // 10px margin
  maxDisplayableLength = max(parseFloat(lengthSlider.elt.min), maxDisplayableLength);
  
  armLength = min(desiredArmLength, maxDisplayableLength);
  if (desiredArmLength > maxDisplayableLength) {
    lengthSlider.value(armLength); // Update slider if capped
  }
  
  angle = radians(initialAngleSlider.value()); // Convert degrees to radians
  angularVelocity = 0;
  angularAcceleration = 0;
}

function draw() {
  // Dynamic background color
  //let hue = (frameCount * 0.2) % 360;
  hue=150;
  background(hue, 150, 75);

  // Update physics parameters from sliders
  gravity = gravitySlider.value();
  damping = dampingSlider.value();

  // Dynamically adjust armLength from slider and cap if necessary
  let desiredArmLength = lengthSlider.value();
  // Max length constraint: must fit vertically below origin, with bobRadius and a small margin
  let maxDisplayableLength = (height - origin.y) - bobRadius - 10; // 10px margin
  // Ensure maxDisplayableLength is not less than the slider's minimum value
  maxDisplayableLength = max(parseFloat(lengthSlider.elt.min), maxDisplayableLength);

  armLength = min(desiredArmLength, maxDisplayableLength);
  if (desiredArmLength > maxDisplayableLength && desiredArmLength > parseFloat(lengthSlider.elt.min) ) {
    // Only update slider if capping actually changed the value and it's not due to maxDisplayable < slider.min
     lengthSlider.value(armLength); 
  }
   // Ensure armLength respects slider's minimum (e.g. if maxDisplayableLength is very small)
  armLength = max(armLength, parseFloat(lengthSlider.elt.min));


  // Physics calculations
  // angularAcceleration = -(gravity / armLength) * sin(angle)
  // (Assumes mass = 1, or rather, mass cancels out for angular acceleration)
  if (armLength > 0) { // Avoid division by zero if armLength somehow becomes zero
    angularAcceleration = (-1 * gravity / armLength) * sin(angle);
  } else {
    angularAcceleration = 0;
  }
  
  angularVelocity += angularAcceleration;
  angularVelocity *= (1 - damping); // Apply damping
  angle += angularVelocity;

  // Drawing the pendulum
  push(); // Isolate transformations: new drawing state
  translate(origin.x, origin.y);

  let bobX = armLength * sin(angle);
  let bobY = armLength * cos(angle); // Angle is from vertical (downwards)

  // Draw arm
  stroke(0, 0, 100); // White arm
  strokeWeight(4);
  line(0, 0, bobX, bobY);

  // Draw bob
  fill((hue + 100) % 360, 90, 90); // Bob color with some hue offset
  noStroke();
  ellipse(bobX, bobY, bobRadius * 2, bobRadius * 2);

  // Draw pivot
  fill(0, 0, 20); // Darker grey pivot
  ellipse(0, 0, 16, 16);
  pop(); // Restore previous drawing state

  // Display current values as text on canvas (optional, good for clarity)
  let textX = UI_X_LABELS;
  let textY = ui_y_current + UI_Y_SPACING - 10; // Position below the reset button
  let textLineHeight = 18;

  fill(0, 0, 0, 60); // Semi-transparent black background for text
  noStroke();
  // Adjusted rect to fit content better
  rect(textX - 10, textY - textLineHeight, UI_X_SLIDERS + UI_SLIDER_WIDTH - textX + 20, textLineHeight * 4 + 10, 5);

  fill(0, 0, 100); // White text
  textSize(13);
  textFont('Arial, sans-serif');
  
  text(`Current Length: ${armLength.toFixed(1)}`, textX, textY); textY += textLineHeight;
  text(`Ângulo atual / Current Angle: ${(degrees(angle) % 360).toFixed(1)}°`, textX, textY); textY += textLineHeight;
  text(`Escala da força da gravidade / Gravity scale: ${gravity.toFixed(2)}`, textX, textY); textY += textLineHeight;
  text(`Amortecimento / Damping: ${damping.toFixed(4)}`, textX, textY);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
  origin.set(width / 2, height / 4);
  // UI elements positions are absolute, so they remain.
  // Arm length capping in draw() and resetPendulum() will handle adjustments.
  // Call resetPendulum to re-evaluate armLength against new canvas dimensions
  // This is optional, draw() loop also handles capping. But good for immediate visual correction.
  // resetPendulum(); // Or just let draw() handle it. Forcing reset might be disruptive.
}
