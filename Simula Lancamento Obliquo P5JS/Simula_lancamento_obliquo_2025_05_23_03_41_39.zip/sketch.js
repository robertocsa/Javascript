// Global variables for sliders and simulation state
let v0Slider, angleSlider, gSlider;
let launchButton;
let projectile;
let isFlying = false;
let trajectory = [];
let predictedPath = [];

let g_sim; // Renomeado para evitar confusão com a função g do p5.js (que não existe)

let initialX_launchPos, initialY_groundLine;
const PROJECTILE_RADIUS = 8;

let maxPhysHeight = 0, rangePhys = 0, flightTime = 0;

function setup() {
    createCanvas(900, 700);
    angleMode(DEGREES); // << MANTIDO, p5.cos/sin agora usam graus

    v0Slider = createSlider(1, 29, 30, 1);
    v0Slider.position(20, 20);
    v0Slider.input(onSliderChange);

    angleSlider = createSlider(0, 90, 45, 1);
    angleSlider.position(20, 50);
    angleSlider.input(onSliderChange);

    gSlider = createSlider(0.01, 3, 0.98, 0.01);
    gSlider.position(20, 80);
    gSlider.input(onSliderChange);

    launchButton = createButton('Lançar');
    launchButton.position(20, 110);
    launchButton.mousePressed(resetAndLaunch);

    initialX_launchPos = 10;
    initialY_groundLine = height - 120;

    projectile = {
        x: initialX_launchPos,
        y: initialY_groundLine - PROJECTILE_RADIUS,
        vx: 0, vy: 0, radius: PROJECTILE_RADIUS
    };
    onSliderChange(); // Calcula primeira previsão e teóricos
}

function onSliderChange() {
    calculateTheoreticals();
    updatePredictedPath();
    if (isFlying) {
        isFlying = false;
        trajectory = [];
        projectile.x = initialX_launchPos;
        projectile.y = initialY_groundLine - PROJECTILE_RADIUS;
        projectile.vx = 0;
        projectile.vy = 0;
    }
}

function calculateTheoreticals() {
    let v0 = v0Slider.value();
    let angle = angleSlider.value(); // Ângulo em graus
    let current_g_val = gSlider.value();

    // Para cálculos teóricos, é comum usar radianos com Math.sin/cos
    let angleRad_calc = radians(angle); // Converter para radianos PARA OS CÁLCULOS FÍSICOS
    let v0y_physics = v0 * Math.sin(angleRad_calc);
    let v0x_physics = v0 * Math.cos(angleRad_calc);

    if (v0 === 0) { maxPhysHeight = 0; flightTime = 0; rangePhys = 0; return; }
    if (current_g_val <= 0) {
        maxPhysHeight = (v0y_physics > 0) ? Infinity : 0;
        flightTime = (v0y_physics > 0 || (v0y_physics === 0 && v0x_physics !== 0)) ? Infinity : 0;
        if (flightTime === Infinity && v0y_physics === 0 && v0x_physics !== 0) flightTime = "N/A (solo)";
        rangePhys = (v0x_physics !== 0) ? Infinity : 0;
        return;
    }
    maxPhysHeight = (v0y_physics * v0y_physics) / (2 * current_g_val);
    if (v0y_physics <= 0) maxPhysHeight = 0;
    flightTime = (2 * v0y_physics) / current_g_val;
    if (flightTime < 0) flightTime = 0;
    rangePhys = v0x_physics * flightTime;
}

function updatePredictedPath() {
    let v0 = v0Slider.value();
    let angle = angleSlider.value(); // Ângulo em graus
    let sim_g_pred = gSlider.value();

    predictedPath = [];
    if (v0 === 0 && angle === 0) {
      predictedPath.push({x: initialX_launchPos, y: initialY_groundLine - PROJECTILE_RADIUS});
      return;
    }

    // p5.js cos() e sin() usarão DEGREES por causa do angleMode()
    let p_vx = v0 * cos(angle);       // << USA GRAUS DIRETAMENTE
    let p_vy = -v0 * sin(angle);      // << USA GRAUS DIRETAMENTE (negativo para cima)

    let currentX = initialX_launchPos;
    let currentY = initialY_groundLine - PROJECTILE_RADIUS;
    predictedPath.push({ x: currentX, y: currentY });

    let maxSteps = 1500;
    for (let i = 0; i < maxSteps; i++) {
        p_vy += sim_g_pred;
        currentX += p_vx;
        currentY += p_vy;
        predictedPath.push({ x: currentX, y: currentY });

        if (currentY + PROJECTILE_RADIUS >= initialY_groundLine) {
            if (predictedPath.length >= 2) {
                let p1 = predictedPath[predictedPath.length - 2];
                let p2 = predictedPath[predictedPath.length - 1];
                let targetY = initialY_groundLine - PROJECTILE_RADIUS;
                if (p2.y !== p1.y) {
                    let t_impact = (targetY - p1.y) / (p2.y - p1.y);
                    if (t_impact >= 0 && t_impact <= 1) {
                        predictedPath[predictedPath.length - 1] = { x: p1.x + t_impact * (p2.x - p1.x), y: targetY };
                    } else { predictedPath[predictedPath.length - 1].y = targetY; }
                } else { predictedPath[predictedPath.length - 1].y = targetY; }
            } else { predictedPath[predictedPath.length - 1].y = initialY_groundLine - PROJECTILE_RADIUS; }
            break;
        }
        if (currentX > width + 50 || currentX < -50 || currentY < -height * 2) break;
    }
}

function resetAndLaunch() {
    let v0 = v0Slider.value();
    let angle = angleSlider.value(); // Ângulo em graus
    g_sim = gSlider.value();

    calculateTheoreticals(); // Usa o ângulo em graus, converte para radianos internamente para Math.cos/sin

    // p5.js cos() e sin() usarão DEGREES por causa do angleMode()
    projectile = {
        x: initialX_launchPos,
        y: initialY_groundLine - PROJECTILE_RADIUS,
        vx: v0 * cos(angle),      // << USA GRAUS DIRETAMENTE
        vy: -v0 * sin(angle),     // << USA GRAUS DIRETAMENTE (negativo para cima)
        radius: PROJECTILE_RADIUS
    };
    // Log para verificar velocidades iniciais
    console.log(`Lançando: v0=${v0}, angle=${angle}deg, g_sim=${g_sim}`);
    console.log(`vx=${projectile.vx.toFixed(2)}, vy_initial=${projectile.vy.toFixed(2)}`);

    trajectory = [];
    trajectory.push({ x: projectile.x, y: projectile.y });
    isFlying = true;
}

function draw() {
    background(220);
    stroke(0); strokeWeight(2);
    line(0, initialY_groundLine, width, initialY_groundLine);

    // Desenha Trajetória Prevista
    if (predictedPath.length > 1) {
        noFill(); stroke(120, 120, 120, 180); strokeWeight(1.5);
        beginShape();
        for (let point of predictedPath) vertex(point.x, point.y);
        endShape();
    }

    // Atualiza e Desenha Projétil em Voo
    if (isFlying) {
        projectile.vy += g_sim; // Usa g_sim (gravidade da simulação)
        projectile.x += projectile.vx;
        projectile.y += projectile.vy;

        if (frameCount % 2 === 0) trajectory.push({ x: projectile.x, y: projectile.y });

        if (projectile.y + projectile.radius >= initialY_groundLine) {
            projectile.y = initialY_groundLine - projectile.radius;
            isFlying = false;
            trajectory.push({ x: projectile.x, y: projectile.y });
        }
    }

    // Desenha Rastro Dinâmico
    if (trajectory.length > 1) {
        noFill(); stroke(0, 0, 255, 150); strokeWeight(2);
        beginShape();
        for (let point of trajectory) vertex(point.x, point.y);
        endShape();
    }

    // Desenha Projétil
    fill(255, 0, 0); noStroke();
    ellipse(projectile.x, projectile.y, projectile.radius * 2, projectile.radius * 2);

    // Display Info
    fill(0); noStroke(); textSize(14);
    text(`Velocidade Inicial (v₀): ${v0Slider.value().toFixed(0)} u/t`, v0Slider.x * 2 + v0Slider.width, v0Slider.y + 15);
    text(`Ângulo (θ): ${angleSlider.value().toFixed(0)}°`, angleSlider.x * 2 + angleSlider.width, angleSlider.y + 15);
    text(`Gravidade (g): ${gSlider.value().toFixed(2)} u/t²`, gSlider.x * 2 + gSlider.width, gSlider.y + 15);

    textSize(16); textStyle(BOLD);
    text("Resultados Teóricos (lançamento do solo):", 20, initialY_groundLine + 30);
    textStyle(NORMAL); textSize(14);
    let textY = initialY_groundLine + 50;

    let ftDisplay = (flightTime === Infinity) ? "Infinito" : (typeof flightTime === 'string' ? flightTime : flightTime.toFixed(2));
    let rangeDisplay = (rangePhys === Infinity) ? "Infinito" : rangePhys.toFixed(2);
    let heightDisplay = (maxPhysHeight === Infinity) ? "Infinita" : maxPhysHeight.toFixed(2);
    if (v0Slider.value() === 0) { ftDisplay = "0.00"; rangeDisplay = "0.00"; heightDisplay = "0.00"; }

    text(`Tempo de Voo Estimado: ${ftDisplay} t`, 20, textY);
    text(`Alcance Máximo Estimado: ${rangeDisplay} u`, 20, textY + 20);
    text(`Altura Máxima Estimada: ${heightDisplay} u`, 20, textY + 40);

    textSize(12); fill(100);
    text("Ajuste os controles e clique em 'Lançar'.", 20, height - 10);
    text("'u' = pixels, 't' = frames", width - 200, height - 10);
}